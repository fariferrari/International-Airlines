from prometheus_client import start_http_server, Gauge, Counter, Histogram, Info
import psycopg2
import time
import random
from datetime import datetime

# Метрики для аэропорта
airport_total_flights = Gauge('airport_total_flights', 'Total number of flights')
airport_flights_today = Gauge('airport_flights_today', 'Flights scheduled for today')
airport_departures_today = Gauge('airport_departures_today', 'Departures today')
airport_arrivals_today = Gauge('airport_arrivals_today', 'Arrivals today')
airport_passengers_total = Gauge('airport_passengers_total', 'Total passengers')
airport_passengers_today = Gauge('airport_passengers_today', 'Passengers today')
airport_delayed_flights = Gauge('airport_delayed_flights', 'Delayed flights count')
airport_active_airlines = Gauge('airport_active_airlines', 'Number of active airlines')
airport_total_bookings = Gauge('airport_total_bookings', 'Total bookings')
airport_security_checks = Gauge('airport_security_checks', 'Security checks today')

# API метрики
api_requests_total = Counter('api_requests_total', 'Total API requests')
db_query_time = Histogram('db_query_time_seconds', 'Database query time')
exporter_info = Info('exporter_info', 'Information about the exporter')

def get_db_connection():
    """Подключение к PostgreSQL базе данных"""
    try:
        conn = psycopg2.connect(
            host="localhost",
            port="5432",
            database="airport_db",
            user="postgres",
            password="farida"  # замени на свой пароль
        )
        return conn
    except Exception as e:
        print(f"❌ Database connection error: {e}")
        return None

def get_airport_metrics():
    """Получение метрик из базы данных аэропорта"""
    conn = get_db_connection()
    if conn is None:
        return generate_demo_metrics()
    
    try:
        cursor = conn.cursor()
        start_time = time.time()
        
        # 1. Общее количество рейсов
        cursor.execute("SELECT COUNT(*) FROM flights;")
        total_flights = cursor.fetchone()[0]
        
        # 2. Рейсы на сегодня
        cursor.execute("SELECT COUNT(*) FROM flights WHERE DATE(departure_time) = CURRENT_DATE;")
        flights_today = cursor.fetchone()[0]
        
        # 3. Вылеты сегодня
        cursor.execute("SELECT COUNT(*) FROM flights WHERE DATE(departure_time) = CURRENT_DATE;")
        departures_today = cursor.fetchone()[0]
        
        # 4. Прилёты сегодня (предполагаем, что есть поле arrival_time)
        cursor.execute("SELECT COUNT(*) FROM flights WHERE DATE(arrival_time) = CURRENT_DATE;")
        arrivals_today = cursor.fetchone()[0]
        
        # 5. Общее количество пассажиров
        cursor.execute("SELECT COUNT(*) FROM passengers;")
        total_passengers = cursor.fetchone()[0]
        
        # 6. Пассажиры сегодня (из бронирований)
        cursor.execute("SELECT COUNT(DISTINCT passenger_id) FROM booking WHERE DATE(booking_date) = CURRENT_DATE;")
        passengers_today = cursor.fetchone()[0]
        
        # 7. Задержанные рейсы (предполагаем поле status)
        cursor.execute("SELECT COUNT(*) FROM flights WHERE status = 'Delayed';")
        delayed_flights = cursor.fetchone()[0]
        
        # 8. Активные авиакомпании
        cursor.execute("SELECT COUNT(DISTINCT airline_id) FROM flights;")
        active_airlines = cursor.fetchone()[0]
        
        # 9. Всего бронирований
        cursor.execute("SELECT COUNT(*) FROM booking;")
        total_bookings = cursor.fetchone()[0]
        
        # 10. Проверки безопасности сегодня
        cursor.execute("SELECT COUNT(*) FROM security_check WHERE DATE(check_time) = CURRENT_DATE;")
        security_checks = cursor.fetchone()[0]
        
        query_time = time.time() - start_time
        db_query_time.observe(query_time)
        
        conn.close()
        
        return {
            'total_flights': total_flights,
            'flights_today': flights_today,
            'departures_today': departures_today,
            'arrivals_today': arrivals_today or 0,
            'total_passengers': total_passengers,
            'passengers_today': passengers_today,
            'delayed_flights': delayed_flights,
            'active_airlines': active_airlines,
            'total_bookings': total_bookings,
            'security_checks': security_checks
        }
        
    except Exception as e:
        print(f"❌ Database query error: {e}")
        conn.close()
        return generate_demo_metrics()

def generate_demo_metrics():
    """Генерация демо-метрик если БД недоступна"""
    return {
        'total_flights': random.randint(1000, 5000),
        'flights_today': random.randint(50, 200),
        'departures_today': random.randint(25, 100),
        'arrivals_today': random.randint(25, 100),
        'total_passengers': random.randint(50000, 500000),
        'passengers_today': random.randint(500, 5000),
        'delayed_flights': random.randint(0, 15),
        'active_airlines': random.randint(5, 50),
        'total_bookings': random.randint(10000, 100000),
        'security_checks': random.randint(100, 1000)
    }

def update_metrics():
    """Обновление всех метрик"""
    metrics = get_airport_metrics()
    
    # Устанавливаем значения метрик
    airport_total_flights.set(metrics['total_flights'])
    airport_flights_today.set(metrics['flights_today'])
    airport_departures_today.set(metrics['departures_today'])
    airport_arrivals_today.set(metrics['arrivals_today'])
    airport_passengers_total.set(metrics['total_passengers'])
    airport_passengers_today.set(metrics['passengers_today'])
    airport_delayed_flights.set(metrics['delayed_flights'])
    airport_active_airlines.set(metrics['active_airlines'])
    airport_total_bookings.set(metrics['total_bookings'])
    airport_security_checks.set(metrics['security_checks'])
    
    api_requests_total.inc()
    
    return metrics

if __name__ == '__main__':
    # Информация об экспортере
    exporter_info.info({
        'version': '1.0.0', 
        'author': 'Student',
        'description': 'Airport PostgreSQL Database Metrics Exporter'
    })
    
    # Запуск HTTP сервера
    start_http_server(8000)
    print("🚀 Airport PostgreSQL Metrics Exporter started on port 8000")
    print("📊 Metrics available at: http://localhost:8000/metrics")
    
    request_count = 0
    
    while True:
        request_count += 1
        print(f"\n🔄 Update #{request_count} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            metrics = update_metrics()
            
            print(f"✈️  Total flights: {metrics['total_flights']:,}")
            print(f"📅 Flights today: {metrics['flights_today']}")
            print(f"🛫 Departures today: {metrics['departures_today']}") 
            print(f"🛬 Arrivals today: {metrics['arrivals_today']}")
            print(f"👥 Total passengers: {metrics['total_passengers']:,}")
            print(f"👤 Passengers today: {metrics['passengers_today']}")
            print(f"⏰ Delayed flights: {metrics['delayed_flights']}")
            print(f"🏢 Active airlines: {metrics['active_airlines']}")
            print(f"📋 Total bookings: {metrics['total_bookings']:,}")
            print(f"🛡️  Security checks: {metrics['security_checks']}")
            
            print("✅ All airport metrics updated successfully!")
            
        except Exception as e:
            print(f"❌ Error updating metrics: {e}")
        
        time.sleep(20)